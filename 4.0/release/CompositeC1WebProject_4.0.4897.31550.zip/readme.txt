If you are using Visual Studio do the following:
 
1. Open the solution file "Composite C1 Website.sln"
2. Open the "Property Page" for the web project
3. To rule out file permission errors, select "Start options" 
and make sure "NTLM Authentication" is not checked.
4. To skip waiting for website compilations:
- Under "Build", "Start action" select "No build"
- Under "Build", "Build solution action" uncheck "Build Website as part of solution"